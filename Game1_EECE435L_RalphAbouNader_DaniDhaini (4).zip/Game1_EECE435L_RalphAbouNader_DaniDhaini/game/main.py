import pygame
import random
import time
import sys
import re
pygame.init()
COLOR_INACTIVE = pygame.Color('lightskyblue3')
COLOR_ACTIVE = pygame.Color('dodgerblue2')
FONT = pygame.font.Font(None, 32)
bg = pygame.image.load("im.jpg")
print(sys.modules[__name__])

class InputBox:
    '''Initializes object positions on the screen and variable to store input text'''
    def __init__(self, x, y, w, h, text=''):
        self.rect = pygame.Rect(x, y, w, h)
        self.color = COLOR_INACTIVE
        self.text = text
        self.txt_surface = FONT.render(text, True, self.color)
        self.active = False
        self.glob = ''


    '''Basic event handling. Detects enter keys and stores user input upon its click'''
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            # If the user clicked on the input_box rect.
            if self.rect.collidepoint(event.pos):
                # Toggle the active variable.
                self.active = not self.active
            else:
                self.active = False
            # Change the current color of the input box.
            self.color = COLOR_ACTIVE if self.active else COLOR_INACTIVE
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_RETURN:

                    print(self.text)
                    # self.text = ''
                elif event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                    # self.text = ''
                else:
                    if event.unicode.isdigit():
                        self.text += event.unicode

                # Re-render the text.
                self.txt_surface = FONT.render(self.text, True, self.color)



    '''Resizes box in case of large inputs
    Will probably never be used in this use case'''
    def update(self):

        width = max(200, self.txt_surface.get_width()+10)
        self.rect.w = width
    '''Displays the input box on the screen according to the x and y positions'''
    def draw(self, screen):

        screen.blit(self.txt_surface, (self.rect.x+5, self.rect.y+5))

        pygame.draw.rect(screen, self.color, self.rect, 2)

    def clear(self):
        self.text = ''


windowSize = (1250,500)

myriadProFont = pygame.font.SysFont("myriadProFont" , 48)
screen = pygame.display.set_mode(windowSize)
x,y = 400, 0
or_pos = (400,0)
lives = 3
clock = pygame.time.Clock()
ti = 0
scores = 0
wrongs = 0
score = myriadProFont.render("Score :" + str(scores), 1, (100,100,255) , (255,255,255))
wrong = myriadProFont.render("Wrong :" + str(wrongs), 1, (100,100,255) , (255,255,255))
livesdisplay = myriadProFont.render("Lives :" + str(lives), 1, (100,100,255) , (255,255,255))
r1 = random.randint(0, 10)
r2= random.randint(0, 10)
answer = r1 + r2

round1 = r1 + r2
s1 = str(r1) + "+" + str(r2)
texting = myriadProFont.render(s1, 1, (100,100,255) , (255,255,255))

round = 0
e = 10
m = 20
h = 100
i = 10
difficulty = 0

input_box1 = InputBox(100, 100, 140, 32)
input_boxes = [input_box1]
screen.blit(bg, (0, 0))
while 1:
    clock.tick(i)


    pygame.display.update()
    screen.blit(bg, (0, 0))

    pygame.draw.line(screen,"Red", (0, 322), (1250, 322))
    input_box1.draw(screen)
    screen.blit(score, (0, 0))
    screen.blit(livesdisplay, (0, 50))
    diff = myriadProFont.render("Press E,M,H for difficulties", (0,0,0) , (0,0,0) )

    screen.blit(diff, (800,0))

    screen.blit(texting, (x, y))
    correct_answer = r1 + r2


    for event in pygame.event.get():

        if event.type == pygame.QUIT : sys.exit()
        for box in input_boxes:
            box.handle_event(event)
        for box in input_boxes:
            box.update()
        for box in input_boxes:
            box.draw(screen)

        if event.type == pygame.KEYDOWN:

            if event.key == pygame.K_RETURN:
                input_box1.draw(screen)
                pygame.display.update()

                print("Hay hiyye" + input_box1.text)
                answerin = input_box1.text

                ''.join(c for c in answerin if c.isdigit())


                print("Enter" + str(answer))
                if int(answerin) == (correct_answer):
                    print(str(answer) + "or" + str(correct_answer))

                    scores += 1
                    score = myriadProFont.render("Score :" + str(scores), 1, (100, 100, 255), (255, 255, 255))
                    livesdisplay = myriadProFont.render("Lives :" + str(lives), 1, (100,100,255) , (255,255,255))


                    print(scores)
                else:
                    lives = lives -1
                    livesdisplay = myriadProFont.render("Lives :" + str(lives), 1, (100,100,255) , (255,255,255))

                screen.blit(bg, (0, 0))
                print("Answer is" + str(answer))
                print("Correct answer is" + str((correct_answer)))
                print(str(scores) + "is now the score")
                if event.unicode == "e":
                    i = e
                    difficulty = 0
                    continue
                elif event.unicode == "m":
                    i = m
                    difficulty = 1
                    continue
                elif event.unicode == "h":
                    i = h
                    difficulty = 2
                    continue


            elif round == 0:
                if round1 == answer:
                    print("")

            else:

                input_box1.draw(screen)
                pygame.display.update()
                wrongs += 1

    # screen.blit(texting, (x,y))

    y+=5

    if(y == 300) :



        input_box1 = InputBox(100, 100, 140, 32)
        input_boxes = [input_box1]


        round+=1
        screen.blit(bg, (0, 0))
        x,y = 400,0
        if difficulty == 0:
            r1 = random.randint(0, 10)
            r2 = random.randint(0, 10)
        elif difficulty == 1:
            r1 = random.randint(20, 50)
            r2 = random.randint(20, 50)
        elif difficulty == 2:
            r1 = random.randint(50, 100)
            r2 = random.randint(50, 100)
        correct_answer = r1 + r2


        screen.blit(bg, (0, 0))

        s1 = str(r1) + "+" + str(r2)

        # screen = pygame.display.set_mode(windowSize)
        input_box1.draw(screen)

        texting = myriadProFont.render(s1, 1, (100, 100, 255), (255, 255, 255))

        pygame.display.update()

    pygame.display.update()

    if(lives==0):
        pygame.quit()



pygame.quit()